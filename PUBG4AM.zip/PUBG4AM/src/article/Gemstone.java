package article;

public class Gemstone {
    public void show(){
        System.out.println("大吉大利，今晚吃鸡！");
    }
}
