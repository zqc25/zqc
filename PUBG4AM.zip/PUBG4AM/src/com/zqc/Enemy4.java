package com.zqc;

public class Enemy4 extends Monster {
    public Enemy4() {
    }

    public Enemy4(String description, int HP, int damage, String attackMethod) {
        super(description, HP, damage, attackMethod);
    }
}
