package com.zqc;

public class HandlerBye extends Handler {
    public HandlerBye(Game game) {
        super(game);
    }

    @Override
    public boolean isBye() {
        System.out.println("很遗憾，再见。");
        return true;
    }
}
