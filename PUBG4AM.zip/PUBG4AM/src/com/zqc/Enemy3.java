package com.zqc;

public class Enemy3 extends Monster {
    public Enemy3() {
    }

    public Enemy3(String description, int HP, int damage, String attackMethod) {
        super(description, HP, damage, attackMethod);
    }
}
