package com.zqc;

import article.Gemstone;
import com.zqc.*;


import java.util.HashMap;
import java.util.Scanner;

public class Game {
    private Room currentRoom;
    private HashMap<String, Handler> handlers = new HashMap<>();
    private Person person = new Person(0,100,40,0,"步枪","godv");
    Gemstone gemstone = new Gemstone();
    private Object Enemy1;
    private Object Enemy2;
    private Object Enemy3;
    private Object Enemy4;



    public Game() {
        handlers.put("go", new HandlerGo(this));
        handlers.put("bye", new HandlerBye(this));
        handlers.put("help", new HandlerHelp(this));
        handlers.put("attack", new HandlerAttack(this));
        handlers.put("change", new HandlerChangeMethod(this));
        createRooms();
    }

    public void createRooms() {

        Room Bootcamp, Ruins, ParadiseResort, Cave, CampCharlie;
        Enemy1 enemy1 = new Enemy1("敌人1", 100, 10, "步枪");
        Enemy2 enemy2 = new Enemy2("敌人2", 30, 20, "步枪");
        Enemy3 enemy3= new Enemy3("敌人3", 60, 30, "狙击枪");
        Enemy4 enemy4= new Enemy4("敌人4", 40, 10, "步枪");

        Bootcamp = new Room("自闭城",null,null);
        Ruins = new Room("遗址",enemy1,null);
        ParadiseResort = new Room("度假村",enemy2,null);
        Cave = new Room("山洞",enemy3,null);
        CampCharlie = new Room("查利营",enemy4,null);

        Bootcamp.setExit("east",Ruins);
        Bootcamp.setExit("south",Cave);
        Bootcamp.setExit("west",ParadiseResort);
        Ruins.setExit("west",Bootcamp);
        ParadiseResort.setExit("east",Bootcamp);
        Cave.setExit("north",Bootcamp);
        Cave.setExit("east",CampCharlie);
        CampCharlie.setExit("west",Cave);
        Ruins.setExit("up",ParadiseResort);
        ParadiseResort.setExit("down",Ruins);

        currentRoom = Bootcamp;
    }

    public void printWelcome()
    {
        System.out.println();
        System.out.println("欢迎来到绝地求生萨诺地图！");
        System.out.println("这是一个大逃杀游戏。你是4AM战队的队长Godv,你的三个队友相继阵亡，此时是决赛圈，场上还有4名敌人。吃鸡在望，加油！");
        System.out.println("      ===              ==                  ===               ===              === ");
        System.out.println("     ==               == ==               ==  ==            ==  ==            === ");
        System.out.println("   ==   ==           ==   ==             ==    ==          ==    ==           === ");
        System.out.println(" ==     ==          ==     ==           ==      ==        ==      ==          === ");
        System.out.println("=============      ===========         ==        ==      ==        ==         === ");
        System.out.println("        ==        ==         ==       ==          ==    ==          ==        === ");
        System.out.println("        ==       ==           ==     ==            ==  ==            ==       === ");
        System.out.println("        ==      ==             ==   ==               ==               ==       =  ");
        System.out.println("如果需要帮助，请输入‘help’。");
        System.out.println();
        this.showPrompt();
    }


    public void goRoom(String direction) {
        Room nextRoom = currentRoom.getExit(direction);
        if (nextRoom == null) {
            System.out.println("那里是毒圈，去了就会被毒死！");
        } else {
           currentRoom = nextRoom;
           showPrompt();
        }

    }



    public void change() {
        if (person.getAttackMethod().equals("步枪")) {
            person.setAttackMethod("狙击枪");
        } else if (person.getAttackMethod().equals("狙击枪")) {
            person.setAttackMethod("步枪");
        }
        System.out.println("切换成功！");
        System.out.println("现在的攻击方式是" + person.getAttackMethod());
        play();
    }



    public void attack() {
        if (person.getAttackMethod().equals(currentRoom.getCreature().getAttackMethod())) {
            if (person.getAttackMethod().equals("近战")) {
                if (currentRoom.getCreature().getHP() / person.getNearDamage() > person.getHP() / currentRoom.getCreature().getDamage()) {
                    System.out.println("你没有战胜" + currentRoom.getCreature().getDescription() + ",很遗憾，你阵亡了。请输入bye,结束游戏");
                    showPrompt();
                } else {
                    System.out.println("你战胜了他！" );
                    person.setWealth(person.getWealth() );
                    person.setHP(person.getHP() - currentRoom.getCreature().getDamage());
                    currentRoom.setCreature(null);

                }
            } else {
                if (currentRoom.getCreature().getHP() / person.getFarDamage() > person.getHP() / currentRoom.getCreature().getDamage()) {
                    System.out.println("你没有战胜" + currentRoom.getCreature().getDescription() + ",很遗憾，你阵亡了。请输入bye,结束游戏");
                    showPrompt();
                } else {
                    if (currentRoom.getCreature().getDescription().equals("Enemy3")) {
                        gemstone.show();
                        Handler handler = new Handler(this);
                        handler.isBye();
                    }
                    System.out.println("你战胜了他！");
                    person.setWealth(person.getWealth() );
                    person.setHP(person.getHP() - currentRoom.getCreature().getDamage());
                    currentRoom.setCreature(null);

                }
            }
        } else {
            System.out.println("请切换你的武器。");
            showPrompt();
        }
        play();
    }
    public void showPrompt() {

        System.out.println("你在" +currentRoom);
        System.out.print("出口有：");
        System.out.print(currentRoom.getExitDesc());
        System.out.println();
        System.out.println("你的属性:" +
                "三级头 三级甲，护甲共计300 " +
                "装备：满配M416和拥有‘GODV’皮肤的Mini14");
        System.out.println();

        if (currentRoom.getCreature() != null) {
            System.out.println("敌人有：" + currentRoom.getCreature().getDescription() +
                    "(" + currentRoom.getCreature().getAttackMethod() + ")");
        }
        System.out.println();
    }


    public void play() {
        Scanner in = new Scanner(System.in);
        while (true) {
            String line = in.nextLine();
            String[] words = line.split(" ");
            Handler handler = handlers.get(words[0]);
            String value = "";
            if (words.length > 1)
                value = words[1];
            if (handler != null) {
                handler.doCmd(value);
                if (handler.isBye())
                    break;
            }
        }
        in.close();
    }

    public static void main(String[] args) {
        Game game = new Game();
        game.printWelcome();
        game.play();
    }
}
