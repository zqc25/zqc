package com.zqc;

public class Monster extends Creature {
    public Monster(){}

    public Monster(String description, int HP, int damage, String attackMethod) {
        super(description, HP, damage, attackMethod);
    }
}
