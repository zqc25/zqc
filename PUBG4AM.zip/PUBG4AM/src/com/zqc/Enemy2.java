package com.zqc;

public class Enemy2 extends Monster {
    public Enemy2() {
    }

    public Enemy2(String description, int HP, int damage, String attackMethod) {
        super(description, HP, damage, attackMethod);
    }
}
