package com.zqc;

public class Enemy1 extends Monster {
    public Enemy1() {
    }

    public Enemy1(String description, int HP, int damage, String attackMethod) {
        super(description, HP, damage, attackMethod);
    }
}
