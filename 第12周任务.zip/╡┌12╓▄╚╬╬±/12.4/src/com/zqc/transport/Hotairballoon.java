package com.zqc.transport;

public class Hotairballoon extends AirTransport {
    @Override
    public void drivingMethod() {
        System.out.println("热气球起飞");
    }

    @Override
    public void load() {
        System.out.println("汽车降落");
    }

    @Override
    public void maintain() {
        System.out.println("汽车检修");
    }

    @Override
    public void addGas() {
        System.out.println("热气球加气");
    }
    public Hotairballoon(String id) {
        super(id);
    }

    public Hotairballoon() {
        super();
    }
}
