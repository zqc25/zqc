package com.zqc.transport;

public class Aircraft extends AirTransport {

    public Aircraft() {
        super();
    }

    @Override
    public void drivingMethod() {
        System.out.println("飞机启动");
    }

    @Override
    public void load() {
        System.out.println("飞机降落");
    }

    @Override
    public void maintain() {
        System.out.println("飞机检修");
    }

    @Override
    public void addGas() {
        System.out.println("飞机加油");
    }

    public Aircraft(String id) {
        super(id);
    }
}
