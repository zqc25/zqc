package com.zqc.transport;

public class Hovercraft extends MaritimeMeansOfTransport{
    @Override
    public void drivingMethod() {
        System.out.println("气垫船启动");
    }

    @Override
    public void load() {
        System.out.println("气垫船进港");
    }

    @Override
    public void maintain() {
        System.out.println("气垫船检修");
    }

    @Override
    public void addGas() {
        System.out.println("气垫船加燃料");
    }
    public Hovercraft(String id) {
        super(id);
    }

    public Hovercraft() {
        super();
    }
}
