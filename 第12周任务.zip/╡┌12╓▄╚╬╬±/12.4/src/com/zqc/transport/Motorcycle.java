package com.zqc.transport;

public class Motorcycle extends LandTransport {
    @Override
    public void drivingMethod() {
        System.out.println("摩托车启动");
    }

    @Override
    public void load() {
        System.out.println("摩托车制动");
    }

    @Override
    public void maintain() {
        System.out.println("摩托车检修");
    }

    @Override
    public void addGas() {
        System.out.println("摩托车加油");
    }

    public Motorcycle(String id) {
        super(id);
    }

    public Motorcycle() {
        super();
    }
}
