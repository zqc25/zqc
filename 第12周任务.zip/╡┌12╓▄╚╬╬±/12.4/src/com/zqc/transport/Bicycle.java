package com.zqc.transport;

public class Bicycle extends LandTransport {
    @Override
    public void drivingMethod() {
        System.out.println("骑着自行车");
    }

    @Override
    public void load() {
        System.out.println("自行车制动");
    }

    @Override
    public void maintain() {
        System.out.println("自行车检修");
    }

    @Override
    public void addGas() {
        System.out.println("自行车车胎加气");
    }
    public Bicycle(String id) {
        super(id);
    }

    public Bicycle() {
        super();
    }
}
