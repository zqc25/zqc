package com.zqc.transport;

public class Automobile extends LandTransport {
    @Override
    public void drivingMethod() {
        System.out.println("汽车启动");
    }

    @Override
    public void load() {
        System.out.println("汽车制动");
    }

    @Override
    public void maintain() {
        System.out.println("汽车检修");
    }

    @Override
    public void addGas() {
        System.out.println("汽车加油");
    }
    public Automobile(String id) {
        super(id);
    }

    public Automobile() {
        super();
    }
}
