package com.zqc.transport;

public abstract class LandTransport extends Transport{
    public LandTransport(String id) {
        super(id);
    }

    public LandTransport() {
        super();
    }
}