package com.zqc.transport;

public class Ship extends MaritimeMeansOfTransport {
    @Override
    public void drivingMethod() {
        System.out.println("轮船启动");
    }

    @Override
    public void load() {
        System.out.println("轮船减速");
    }

    @Override
    public void maintain() {
        System.out.println("轮船维修");
    }

    @Override
    public void addGas() {
        System.out.println("轮船加油");
    }
    public Ship(String id) {
        super(id);
    }

    public Ship() {
        super();
    }
}