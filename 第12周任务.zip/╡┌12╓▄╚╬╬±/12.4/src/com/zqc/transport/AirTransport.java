package com.zqc.transport;

public abstract class AirTransport extends Transport {
    public AirTransport(String id) {
        super(id);
    }

    public AirTransport() {
        super();
    }
}
