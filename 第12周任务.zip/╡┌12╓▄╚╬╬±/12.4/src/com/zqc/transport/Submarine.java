package com.zqc.transport;

public class Submarine extends MaritimeMeansOfTransport{
    @Override
    public void drivingMethod() {
        System.out.println("潜艇启动下潜");
    }

    @Override
    public void load() {
        System.out.println("潜艇减速上浮");
    }

    @Override
    public void maintain() {
        System.out.println("潜艇检修");
    }

    @Override
    public void addGas() {
        System.out.println("潜艇加燃料");
    }
    public Submarine(String id) {
        super(id);
    }

    public Submarine() {
        super();
    }
}

