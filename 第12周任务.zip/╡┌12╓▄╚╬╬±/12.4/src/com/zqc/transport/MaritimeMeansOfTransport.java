package com.zqc.transport;

public abstract class MaritimeMeansOfTransport extends Transport {
    public MaritimeMeansOfTransport(String id) {
        super(id);
    }

    public MaritimeMeansOfTransport() {
        super();
    }
}
