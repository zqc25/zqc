package com.zqc.transport;

public class Airship extends AirTransport {
    @Override
    public void drivingMethod() {
        System.out.println("飞艇启动");
    }

    @Override
    public void load() {
        System.out.println("飞艇加速");
    }

    @Override
    public void maintain() {
        System.out.println("飞艇检修");
    }

    @Override
    public void addGas() {
        System.out.println("飞艇加油");
    }

    public Airship(String id) {
        super(id);
    }

    public Airship() {
        super();
    }
}
