package com.zqc.transport;

import java.util.Date;

public abstract class Transport {
    private String ownership;
    private String GPSPosition;
    private String price;
    private Date dateOfPurrchase;
    private String id;
    public abstract void drivingMethod();
    public abstract void load();
    public abstract void maintain();
    public abstract void addGas();


    public String getOwnership() {
        return ownership;
    }

    public void setOwnership(String ownership) {
        this.ownership = ownership;
    }

    public String getGPSPosition() {
        return GPSPosition;
    }

    public void setGPSPosition(String GPSPosition) {
        this.GPSPosition = GPSPosition;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public Date getDateOfPurrchase() {
        return dateOfPurrchase;
    }

    public void setDateOfPurrchase(Date dateOfPurrchase) {
        this.dateOfPurrchase = dateOfPurrchase;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Transport(String id) {
        this.id = id;
    }

    public Transport() {
    }
}
