package com.zqc;

import com.zqc.person.Person;
import com.zqc.transport.Aircraft;
import com.zqc.transport.Motorcycle;
/**
 * @descript :
 * @author :zqc
 * @date :2020/5/18 23:22
 * @Param: null
 * @return :
 * @throws :
 * @since :
 */

public class Main {

    public static void main(String[] args) {
	// write your code here
        Person GD =new Person("001");
        Aircraft aircraft =new Aircraft("747号");
        Motorcycle motorcycle =new Motorcycle("宇宙无敌大爆炸号");
        GD.driveTransport(aircraft);
        GD.driveTransport(motorcycle);
    }
}
