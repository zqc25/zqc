package com.zqc.person;

import com.zqc.transport.AirTransport;
import com.zqc.transport.LandTransport;
import com.zqc.transport.MaritimeMeansOfTransport;
/**
 * @descript :
 * @author :zqc
 * @date :2020/5/18 22:31
 * @Param: null
 * @return :
 * @throws :
 * @since :
 */


public class Person {
    private String id;
    private String  p_name;
    private String p_Age;
    private String p_Sex;
    public void driveTransport(AirTransport airTransport){

        System.out.println(airTransport.getId());
    }
    public void driveTransport(LandTransport landTransport){

        System.out.println(landTransport.getId());
    }
    public void driveTransport(MaritimeMeansOfTransport maritimeMeansOfTransport){

        System.out.println(maritimeMeansOfTransport.getId());
    }

    public Person(String id) {
        this.id = id;
    }

    public Person() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getP_name() {
        return p_name;
    }

    public void setP_name(String p_name) {
        this.p_name = p_name;
    }

    public String getP_Age() {
        return p_Age;
    }

    public void setP_Age(String p_Age) {
        this.p_Age = p_Age;
    }

    public String getP_Sex() {
        return p_Sex;
    }

    public void setP_Sex(String p_Sex) {
        this.p_Sex = p_Sex;
    }
}
