package com.zqc;

import com.zqc.person.Person;
import com.zqc.transport.Motorcycle;
/**
 * @descript :
 * @author :zqc
 * @date :2020/5/18 22:42
 * @Param: null
 * @return :
 * @throws :
 * @since :
 */

public class Main {

    public static void main(String[] args) {
	// write your code here
        Person GD = new Person("001");

        Motorcycle motorcycle=new Motorcycle("宇宙无敌大爆炸号");

        GD.driveTransport(motorcycle);
    }
}
