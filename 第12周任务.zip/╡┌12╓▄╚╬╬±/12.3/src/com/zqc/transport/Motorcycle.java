package com.zqc.transport;

public class Motorcycle extends LandTransport {
    public Motorcycle(String id) {
        super(id);
    }

    public Motorcycle() {
        super();
    }
}
