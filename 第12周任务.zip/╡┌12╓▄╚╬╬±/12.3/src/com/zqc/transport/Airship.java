package com.zqc.transport;

public class Airship extends AirTransport {
    public Airship() {
        super();
    }

    public Airship(String id) {
        super(id);
    }
}
