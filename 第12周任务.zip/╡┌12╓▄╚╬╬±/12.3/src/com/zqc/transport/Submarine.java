package com.zqc.transport;

public class Submarine extends MaritimeMeansOfTransport {
    public Submarine(String id) {
        super(id);
    }

    public Submarine() {
        super();
    }
}
