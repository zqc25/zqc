package com.zqc.transport;

public class Automobile extends LandTransport {
    public Automobile(String id) {
        super(id);
    }

    public Automobile() {
        super();
    }
}
