package com.zqc.transport;

public class Airship extends AirTransport {
    public Airship(String id) {
        super(id);
    }

    public Airship() {
        super();
    }
}
