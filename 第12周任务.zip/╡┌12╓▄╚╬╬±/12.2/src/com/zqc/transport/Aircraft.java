package com.zqc.transport;

public class Aircraft extends AirTransport {
    public Aircraft() {
        super();
    }

    public Aircraft(String id) {
        super(id);
    }
}
