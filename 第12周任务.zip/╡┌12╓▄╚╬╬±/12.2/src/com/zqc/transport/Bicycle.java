package com.zqc.transport;

public class Bicycle extends LandTransport{
    public Bicycle(String id) {
        super(id);
    }

    public Bicycle() {
        super();
    }
}
