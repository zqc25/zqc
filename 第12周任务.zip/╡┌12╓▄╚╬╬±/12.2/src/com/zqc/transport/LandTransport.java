package com.zqc.transport;

public class LandTransport extends Transport{
    public LandTransport(String id) {
        super(id);
    }

    public LandTransport() {
        super();
    }
}
