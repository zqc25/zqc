package com.zqc.transport;

public class Hotairballoon extends AirTransport{
    public Hotairballoon(String id) {
        super(id);
    }

    public Hotairballoon() {
        super();
    }
}
