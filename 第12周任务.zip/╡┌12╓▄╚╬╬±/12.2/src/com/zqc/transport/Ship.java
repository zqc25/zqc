package com.zqc.transport;

public class Ship  extends  MaritimeMeansOfTransport{
    public Ship(String id) {
        super(id);
    }

    public Ship() {
        super();
    }
}
