package com.zqc.transport;

public class Hovercraft extends MaritimeMeansOfTransport{
    public Hovercraft(String id) {
        super(id);
    }

    public Hovercraft() {
        super();
    }
}
