package com.zqc.transport;

public class MaritimeMeansOfTransport extends Transport{
    public MaritimeMeansOfTransport(String id) {
        super(id);
    }

    public MaritimeMeansOfTransport() {
        super();
    }
}
