package com.zqc;

import com.zqc.person.Person;
import com.zqc.transport.Motorcycle;
/**
 * @descript :
 * @author :zqc
 * @date :2020/5/18 21:31
 * @Param: null
 * @return :
 * @throws :
 * @since :
 */


public class Main {

    public static void main(String[] args) {
	// write your code here
        Person tom =new Person("001");
        Motorcycle motorcycle =new Motorcycle("025");
        tom.driveTransport(motorcycle);
    }
}
