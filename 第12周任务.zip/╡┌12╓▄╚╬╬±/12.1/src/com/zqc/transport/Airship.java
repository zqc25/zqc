package com.zqc.transport;

import java.util.Date;
/**
 * @descript :
 * @author :zqc
 * @date :2020/5/18 20:53
 * @Param: null
 * @return :
 * @throws :
 * @since :
 */

public class Airship {
    private String ownership;
    private String GPSPosition;
    private String price;
    private Date dateOfPurrchase;
    private String id;
    public void drivingMethod(){
        System.out.println("飞艇启动了");
    }

    public String getOwnership() {
        return ownership;
    }

    public void setOwnership(String ownership) {
        this.ownership = ownership;
    }

    public String getGPSPosition() {
        return GPSPosition;
    }

    public void setGPSPosition(String GPSPosition) {
        this.GPSPosition = GPSPosition;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public Date getDateOfPurrchase() {
        return dateOfPurrchase;
    }

    public void setDateOfPurrchase(Date dateOfPurrchase) {
        this.dateOfPurrchase = dateOfPurrchase;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Airship() {
    }

    public Airship(String id) {
        this.id = id;
    }
}
