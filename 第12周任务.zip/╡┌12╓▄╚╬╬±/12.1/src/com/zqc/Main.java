package com.zqc;
/**
 * @descript :
 * @author :zqc
 * @date :2020/5/18 20:52
 * @Param: null
 * @return :
 * @throws :
 * @since :
 */

import com.zqc.person.Person;
import com.zqc.transport.Motorcycle;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Person person =new Person("001");
        Motorcycle motorcycle=new Motorcycle();
        person.driveTransport(motorcycle);
    }
}
